<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Card;
use App\Models\Collection;
use App\Models\Venta;


class VentasController extends Controller
{
//DAR DE ALTA UNA VENTA
    public function createVenta(Request $request){

        $response = "";
    
        //Getting data from request
        $data = $request->getContent();
    
        //Verify data exists
        $data = json_decode($data);
    
        if($data!=""){
            //TODO: validate user input data 
            if($data){
    
                //Create user
                $venta = new Venta();
    
    
                //Required data
                $venta->card_id = $data->card;
                $venta->amount =$data->amount;
                $venta->price = $data->price;
                $venta->user_id = $data->user;

                //Save venta
                try{
    
                    $venta->save();
    
                    $response = "OK. Data saved";
                }catch(\Exception $e){
                    $response = $e->getMessage();
                }
    
            }
    
        }else{
            $response = "Wrong data";
        }
        
    
    
        return response($response);
    }



    //BUSCADOR DE CARTAS POR NOMBRE O ID
    public function searchCard(Request $request){

    $response = "";
    $busqueda = [];
    $price = 0;
    $amount = 0;

    $data = $request->getContent();
    $data = json_decode($data);

    $cardID = Card::where('name',$data->name)->value('id');
    $card = Card::find($cardID);

    $search = [];

    foreach($card->index as $index){

        $collectionName = $index->collection->name; 
    
    }
    foreach($card->venta as $venta){

        $price = $venta->price;
        $amount = $venta->amount;

    }

    $search[] = [

        "Card ID" => $card->id,
        "Card name" => $card->name,
        "Card description" => $card->description,
        "Collection name" => $collectionName,
        "Price" => $price,
    ];


            
       return $search;

       }       

      // return $venta;
    }

