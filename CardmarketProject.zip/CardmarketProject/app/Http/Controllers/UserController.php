<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Passport\HasApiTokens;

use App\Models\User;


class UserController extends Controller
{
    
public function createUser(Request $request){

    $response = "";

    //Getting data from request
    $data = $request->getContent();

    //Verify data exists
    $data = json_decode($data);

    if($data!=""){
        //TODO: validate user input data 
        if($data){

            //Create user
            $user = new User();


            //Required data
            $user->username = $data->username;
            $user->password = Hash::make($data->password);
            $user->email = $data->email;
            $user->rol = $data->rol;
            //Save user
            try{

                $user->save();

                $response = "OK. Data saved";
            }catch(\Exception $e){
                $response = $e->getMessage();
            }

        }

    }else{
        $response = "Wrong data";
    }
    


    return response($response);
}
public function loginUser(Request $request){

    $response = "";

    //Getting data from request
    $data = $request->getContent();

    //Verify data exists
    $data = json_decode($data);

   //Get password from username
    $hashedPassword = User::where('username', $data->username)->value('password');
    //Password from response
    $responsePassword = $data->password;
    //Find what ID the user has based on his username
    $userLoggedId = User::where('username',$data->username)->value('id');
    $userLogged=User::find($userLoggedId);

    if($data!=""){
        //TODO: validate user input data 
        if($data){

            //Check if user and password exists in the database
            if (User::where('username', '=', $data->username)->exists() && Hash::check($responsePassword , $hashedPassword)) {
                
                //Token from laravel passport
               $token = $userLogged->createToken('administrador')->accessToken;
               //Put laravel passport token into username token field
               $userLogged->api_token = $token;
               $userLogged->save();
                $userRol = User::where('username', $data->username)->value('rol');
                //The token is needed in order to access the system
                return response()->json([

                    'respuesta' => 'Logged as'." ".$userRol,

                    'token'=>$token,
                    'id'=>$userLogged->id
                ]);     

            }else{
                return 'Username or password are incorrect';
            }

    }else{
        $response = "Wrong data input";
    }
    


    return response($response);
}

}

public function changePassword(Request $request){

    $response = "";

    //Getting data from request
    $data = $request->getContent();

    //Verify data exists
    $data = json_decode($data);

    //Create new user
    $user = User::where('email', $data->email)->first();


    $userPassword = User::where('email', $data->email)->value('password');
    
        if(isset($userPassword)){

            //Create new password and then hash it
            $randomPassword = uniqid();
            $newHashedPassword =  Hash::make($randomPassword);
            
            //Change password 
            $user->password = $newHashedPassword;
            
            //save changes
            $user->save();
                return "Password changed, new password is ". $randomPassword;

        }
      


    

    return response($response);
}

}