<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Card;
use App\Models\Collection;
use Illuminate\Support\Str;

class CardsController extends Controller
{

    public function createCard(Request $request){

    $response = "";

    //Getting data from request
    $data = $request->getContent();

    //Verify data exists
    $data = json_decode($data);

    if($data!=""){
        //TODO: validate user input data 
        if($data){

            //Create card
            $card = new Card();


            //Required data
            $card->name = $data->name;
            $card->description =$data->description;
           // $card->secret_code = Str::random(40);
        
            //Save card
            try{

                $card->save();

                $response = "OK. Data saved";
            }catch(\Exception $e){
                $response = $e->getMessage();
            }

        }

    }else{
        $response = "Wrong data";
    }
    


    return response($response);

}


}
