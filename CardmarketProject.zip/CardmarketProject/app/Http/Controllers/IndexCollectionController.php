<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndexCollectionController extends Controller
{
    //
}
