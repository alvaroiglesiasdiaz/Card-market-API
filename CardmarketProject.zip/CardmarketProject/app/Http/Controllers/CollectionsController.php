<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Card;
use App\Models\Collection;
use App\Models\IndexCollection;

use Illuminate\Support\Str;

class CollectionsController extends Controller
{

    public function storeCardCollection(Request $request){
        $response = "";
        $isStored = false;

        //Getting data from request
        $data = $request->data;
        //Verify data exists
        $data = json_decode($data);
    
        $collection = new Collection();
        $collections = Collection::all();

        $card = new Card();
        $cards = Card::all();

        $index = new IndexCollection();
        if($data){

            if($request->hasFile('symbol')){

                $path = $request->file('symbol')->getRealPath();
                $symbol = file_get_contents($path);
                $base64 = base64_encode($symbol);
                $collection->symbol = $base64;
               // $response = "<img src='data:image/png;base64,".$base64."'>";

            }
            foreach ($collections as $savedCollection) {

                if($data->name == $savedCollection->name){

                    $isStored = true;
                }
            }

            if($isStored){
                $response = "This collection already exists.";
            }else{
                $collection->name = $data->name;

                foreach($cards as $savedCard){
                    if($data->cardName ==$savedCard->name){

                        $savedCardID = $savedCard->id;

                    }

                }
            
                
               
            try{

                
                $collection->save();

                if(Str::contains($request->symbol, 'png')){
                    $response .= "<img src='data:image/png;base64,".$collection->symbol."'>";
                }else{
                    $response .= "<img src='data:image/jpeg;base64,".$collection->symbol."'>";
                }


                if(isset($savedCardID)){
                    $index->card_id = $savedCardID;
                    $response = "Card successfully added to collection";

                }else{
                    $card->name = $data->cardName;
                    $card->description = $data->description;
                    $card->save();
                    $index->card_id = $card->id;
                    $response = "The collection has been created with the card";

                }
                $index->collection_id = $collection->id;
                $index->save();
            }catch(\Exception $e){
                $response = $e->getMessage();
            }
        }
        }else{
            $response = "Wrong data";
        }
        return response($response."<img src='data:image/jpeg;base64,".$collection->symbol."'>");







    }
}
